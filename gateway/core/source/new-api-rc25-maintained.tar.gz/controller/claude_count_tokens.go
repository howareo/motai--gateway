package controller

import (
	"net/http"

	"github.com/QuantumNous/new-api/relay/helper"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
)

// CountClaudeTokens implements Anthropic's local count_tokens compatibility
// endpoint. It deliberately never selects a channel, calls an upstream, or
// enters billing; Claude Code uses it only to size the next request.
func CountClaudeTokens(c *gin.Context) {
	request, err := helper.GetAndValidateClaudeRequest(c)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"type": "error",
			"error": gin.H{
				"type":    "invalid_request_error",
				"message": err.Error(),
			},
		})
		return
	}

	meta := request.GetTokenCountMeta()
	inputTokens := service.CountTextToken(meta.CombineText, request.Model)
	// Claude's local estimator accounts for media separately from text. The
	// endpoint is primarily used for classifier text, but preserve a stable
	// estimate for requests containing media blocks as well.
	inputTokens += len(meta.Files) * 520
	if inputTokens < 0 {
		inputTokens = 0
	}

	c.JSON(http.StatusOK, gin.H{"input_tokens": inputTokens})
}
