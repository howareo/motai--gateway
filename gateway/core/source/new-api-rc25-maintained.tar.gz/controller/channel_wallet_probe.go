package controller

import (
	"context"
	"io"
	"math"
	"mime"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
)

const (
	walletProbeMaxBodyBytes = 64 * 1024
	walletProbeMinInterval  = time.Minute
	walletProbeTimeout      = 10 * time.Second
)

type walletProbeResult struct {
	ChannelID  int      `json:"channel_id"`
	Status     string   `json:"status"`
	Adapter    string   `json:"adapter"`
	Balance    *float64 `json:"balance,omitempty"`
	Currency   *string  `json:"currency,omitempty"`
	FetchedAt  string   `json:"fetched_at"`
	ErrorClass string   `json:"error_class,omitempty"`
}

var walletProbeDebounce = struct {
	sync.Mutex
	lastAttempt map[int]time.Time
}{lastAttempt: make(map[int]time.Time)}

func buildWalletProbeURL(baseURL, endpoint string) (*url.URL, string) {
	parsed, err := url.Parse(strings.TrimSpace(baseURL))
	if err != nil || parsed.Scheme != "https" || parsed.Hostname() == "" || parsed.User != nil {
		return nil, "invalid_target"
	}
	parsed.RawQuery = ""
	parsed.Fragment = ""
	basePath := strings.TrimRight(parsed.EscapedPath(), "/")
	basePath = strings.TrimSuffix(basePath, "/v1")
	path := basePath + endpoint
	decodedPath, err := url.PathUnescape(path)
	if err != nil {
		return nil, "invalid_target"
	}
	parsed.Path = decodedPath
	parsed.RawPath = ""
	return parsed, ""
}

func fetchWalletProbeJSON(ctx context.Context, client *http.Client, target *url.URL, key string, destination any) string {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target.String(), nil)
	if err != nil {
		return "invalid_target"
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(key))
	resp, err := client.Do(req)
	if err != nil {
		return classifySub2BillingProbeError(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound || resp.StatusCode == http.StatusMethodNotAllowed {
		return "endpoint_unsupported"
	}
	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		return "redirect_blocked"
	}
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		return "unauthorized"
	}
	if resp.StatusCode >= 400 && resp.StatusCode < 500 {
		return "http_4xx"
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "http_5xx"
	}
	mediaType, _, err := mime.ParseMediaType(resp.Header.Get("Content-Type"))
	if err != nil || (mediaType != "application/json" && !strings.HasSuffix(mediaType, "+json")) {
		return "bad_content_type"
	}
	if resp.ContentLength > walletProbeMaxBodyBytes {
		return "response_too_large"
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, walletProbeMaxBodyBytes+1))
	if err != nil {
		return "response_read_error"
	}
	if len(body) > walletProbeMaxBodyBytes {
		return "response_too_large"
	}
	if err := common.Unmarshal(body, destination); err != nil {
		return "schema_invalid"
	}
	return ""
}

func executeWalletProbe(ctx context.Context, channel *model.Channel) walletProbeResult {
	return executeWalletProbeWithClient(ctx, channel, service.NewStrictProtectedFetchHTTPClient(walletProbeTimeout))
}

func executeWalletProbeWithClient(ctx context.Context, channel *model.Channel, client *http.Client) walletProbeResult {
	result := walletProbeResult{
		ChannelID: channel.Id,
		Status:    "failed",
		Adapter:   "newapi",
		FetchedAt: time.Now().UTC().Format(time.RFC3339Nano),
	}
	if strings.TrimSpace(channel.GetSetting().Proxy) != "" {
		result.Status = "unsupported"
		result.ErrorClass = "channel_proxy_unsupported"
		return result
	}
	key, _, apiErr := channel.GetNextEnabledKey()
	if apiErr != nil || strings.TrimSpace(key) == "" {
		result.ErrorClass = "key_unavailable"
		return result
	}
	subscriptionURL, errorClass := buildWalletProbeURL(channel.GetBaseURL(), "/v1/dashboard/billing/subscription")
	if errorClass != "" {
		result.ErrorClass = errorClass
		return result
	}
	usageURL, errorClass := buildWalletProbeURL(channel.GetBaseURL(), "/v1/dashboard/billing/usage")
	if errorClass != "" {
		result.ErrorClass = errorClass
		return result
	}

	var subscription OpenAISubscriptionResponse
	if errorClass = fetchWalletProbeJSON(ctx, client, subscriptionURL, key, &subscription); errorClass != "" {
		if errorClass == "endpoint_unsupported" {
			result.Status = "unsupported"
		}
		result.ErrorClass = errorClass
		return result
	}
	var usage OpenAIUsageResponse
	if errorClass = fetchWalletProbeJSON(ctx, client, usageURL, key, &usage); errorClass != "" {
		if errorClass == "endpoint_unsupported" {
			result.Status = "unsupported"
		}
		result.ErrorClass = errorClass
		return result
	}
	if subscription.Object == "" || usage.Object == "" || math.IsNaN(subscription.HardLimitUSD) || math.IsInf(subscription.HardLimitUSD, 0) || math.IsNaN(usage.TotalUsage) || math.IsInf(usage.TotalUsage, 0) {
		result.ErrorClass = "schema_invalid"
		return result
	}
	balance := subscription.HardLimitUSD - usage.TotalUsage/100
	if math.IsNaN(balance) || math.IsInf(balance, 0) || math.Abs(balance) > 1e12 {
		result.ErrorClass = "value_out_of_band"
		return result
	}
	result.Status = "ok"
	result.Balance = &balance
	return result
}

// ProbeChannelWallet queries only the fixed OpenAI-compatible billing
// endpoints with the channel's stored key. It is independent of the channel
// relay protocol and never returns the key or raw upstream response bodies.
func ProbeChannelWallet(c *gin.Context) {
	channelID, err := strconv.Atoi(c.Param("id"))
	if err != nil || channelID <= 0 {
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "message": "invalid channel id", "code": "INVALID_CHANNEL_ID"})
		return
	}
	now := time.Now()
	walletProbeDebounce.Lock()
	lastAttempt := walletProbeDebounce.lastAttempt[channelID]
	if !lastAttempt.IsZero() && now.Sub(lastAttempt) < walletProbeMinInterval {
		walletProbeDebounce.Unlock()
		c.JSON(http.StatusTooManyRequests, gin.H{"success": false, "message": "probe rate limited", "code": "PROBE_RATE_LIMITED"})
		return
	}
	walletProbeDebounce.lastAttempt[channelID] = now
	walletProbeDebounce.Unlock()

	channel, err := model.GetChannelById(channelID, true)
	if err != nil || channel == nil {
		c.JSON(http.StatusNotFound, gin.H{"success": false, "message": "channel not found", "code": "CHANNEL_NOT_FOUND"})
		return
	}
	startedAt := time.Now()
	result := executeWalletProbe(c.Request.Context(), channel)
	probeURL, _ := buildWalletProbeURL(channel.GetBaseURL(), "/v1/dashboard/billing/subscription")
	host := ""
	if probeURL != nil {
		host = probeURL.Hostname()
	}
	recordManageAudit(c, "channel.wallet_probe", map[string]interface{}{
		"id":          channelID,
		"target_host": host,
		"result":      result.Status,
		"error_class": result.ErrorClass,
		"duration_ms": time.Since(startedAt).Milliseconds(),
	})
	c.JSON(http.StatusOK, gin.H{"success": true, "message": "", "data": result})
}
