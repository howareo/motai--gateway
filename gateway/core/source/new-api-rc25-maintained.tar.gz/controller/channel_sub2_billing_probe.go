package controller

import (
	"context"
	"errors"
	"io"
	"math"
	"mime"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
)

const (
	sub2BillingProbeMaxBodyBytes = 64 * 1024
	sub2BillingProbeMinInterval  = time.Minute
	sub2BillingProbeTimeout      = 10 * time.Second
)

type sub2BillingProbePayload struct {
	Object                  string  `json:"object"`
	SchemaVersion           int     `json:"schema_version"`
	BillingScope            string  `json:"billing_scope"`
	EffectiveRateMultiplier float64 `json:"effective_rate_multiplier"`
	ObservedAt              string  `json:"observed_at"`
}

type sub2BillingProbeResult struct {
	ChannelID               int      `json:"channel_id"`
	Status                  string   `json:"status"`
	ErrorClass              string   `json:"error_class,omitempty"`
	Source                  string   `json:"source,omitempty"`
	UpstreamGroup           string   `json:"upstream_group,omitempty"`
	SchemaVersion           int      `json:"schema_version,omitempty"`
	BillingScope            string   `json:"billing_scope,omitempty"`
	EffectiveRateMultiplier *float64 `json:"effective_rate_multiplier,omitempty"`
	ObservedAt              string   `json:"observed_at,omitempty"`
	FetchedAt               string   `json:"fetched_at"`
}

const (
	newAPIUsageTokenPath    = "/api/usage/token/"
	newAPIPricingPath       = "/api/pricing"
	newAPIMessagesPath      = "/v1/messages"
	newAPIUnknownModelProbe = "newapi-group-probe-nonexistent"
)

// sub2BillingProbeSupportedTypes lists every channel type whose upstream can
// answer /api/usage/token/ + /api/pricing. Add new relays here, not at the
// call sites.
var sub2BillingProbeSupportedTypes = map[int]bool{
	constant.ChannelTypeOpenAI:    true,
	constant.ChannelTypeAnthropic: true,
	constant.ChannelTypeXai:       true,
	constant.ChannelTypeGemini:    true,
	constant.ChannelTypeMoonshot:  true,
	constant.ChannelTypeZhipu:     true,
	constant.ChannelTypeZhipu_v4:  true,
	constant.ChannelTypeDeepSeek:  true,
}

func sub2BillingProbeSupportsChannelType(channelType int) bool {
	return sub2BillingProbeSupportedTypes[channelType]
}

var newAPIUpstreamGroupPattern = regexp.MustCompile(`under group ([^()\r\n]+?) \(distributor\)`)

var sub2BillingProbeDebounce = struct {
	sync.Mutex
	lastAttempt map[int]time.Time
}{lastAttempt: make(map[int]time.Time)}

func buildSub2BillingProbeURL(baseURL string) (*url.URL, string) {
	parsed, err := url.Parse(strings.TrimSpace(baseURL))
	if err != nil || parsed.Scheme != "https" || parsed.Hostname() == "" || parsed.User != nil {
		return nil, "invalid_target"
	}
	parsed.RawQuery = ""
	parsed.Fragment = ""
	path := strings.TrimRight(parsed.EscapedPath(), "/")
	if strings.HasSuffix(path, "/v1") {
		path += "/sub2api/billing"
	} else {
		path += "/v1/sub2api/billing"
	}
	decodedPath, err := url.PathUnescape(path)
	if err != nil {
		return nil, "invalid_target"
	}
	parsed.Path = decodedPath
	parsed.RawPath = ""
	return parsed, ""
}

func classifySub2BillingProbeError(err error) string {
	if err == nil {
		return ""
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return "timeout"
	}
	var netErr net.Error
	if errors.As(err, &netErr) && netErr.Timeout() {
		return "timeout"
	}
	text := strings.ToLower(err.Error())
	switch {
	case strings.Contains(text, "private ip"), strings.Contains(text, "not allowed"), strings.Contains(text, "not in whitelist"):
		return "target_blocked"
	case strings.Contains(text, "dns") || strings.Contains(text, "lookup"):
		return "dns_error"
	case strings.Contains(text, "tls") || strings.Contains(text, "certificate"):
		return "tls_error"
	default:
		return "network_error"
	}
}

func executeSub2BillingProbe(ctx context.Context, channel *model.Channel) sub2BillingProbeResult {
	return executeSub2BillingProbeWithClient(ctx, channel, service.NewStrictProtectedFetchHTTPClient(sub2BillingProbeTimeout))
}

func executeSub2BillingProbeWithClient(ctx context.Context, channel *model.Channel, client *http.Client) sub2BillingProbeResult {
	result := sub2BillingProbeResult{
		ChannelID: channel.Id,
		Status:    "failed",
		FetchedAt: time.Now().UTC().Format(time.RFC3339Nano),
	}
	if !sub2BillingProbeSupportsChannelType(channel.Type) {
		result.Status = "unsupported"
		result.ErrorClass = "channel_type_unsupported"
		return result
	}
	if strings.TrimSpace(channel.GetSetting().Proxy) != "" {
		result.Status = "unsupported"
		result.ErrorClass = "channel_proxy_unsupported"
		return result
	}
	probeURL, errorClass := buildSub2BillingProbeURL(channel.GetBaseURL())
	if errorClass != "" {
		result.ErrorClass = errorClass
		return result
	}
	key, _, apiErr := channel.GetNextEnabledKey()
	if apiErr != nil || strings.TrimSpace(key) == "" {
		result.ErrorClass = "key_unavailable"
		return result
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, probeURL.String(), nil)
	if err != nil {
		result.ErrorClass = "invalid_target"
		return result
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(key))

	resp, err := client.Do(req)
	if err != nil {
		result.ErrorClass = classifySub2BillingProbeError(err)
		return result
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound || resp.StatusCode == http.StatusMethodNotAllowed {
		result.Status = "unsupported"
		result.ErrorClass = "endpoint_unsupported"
		return result
	}
	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		result.ErrorClass = "redirect_blocked"
		return result
	}
	if resp.StatusCode >= 400 && resp.StatusCode < 500 {
		result.ErrorClass = "http_4xx"
		return result
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		result.ErrorClass = "http_5xx"
		return result
	}
	mediaType, _, err := mime.ParseMediaType(resp.Header.Get("Content-Type"))
	if err != nil || mediaType != "application/json" {
		result.ErrorClass = "bad_content_type"
		return result
	}
	if resp.ContentLength > sub2BillingProbeMaxBodyBytes {
		result.ErrorClass = "response_too_large"
		return result
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, sub2BillingProbeMaxBodyBytes+1))
	if err != nil {
		result.ErrorClass = "response_read_error"
		return result
	}
	if len(body) > sub2BillingProbeMaxBodyBytes {
		result.ErrorClass = "response_too_large"
		return result
	}
	var payload sub2BillingProbePayload
	if err := common.Unmarshal(body, &payload); err != nil {
		result.ErrorClass = "schema_invalid"
		return result
	}
	value := payload.EffectiveRateMultiplier
	if payload.Object != "sub2api.key_billing" || payload.SchemaVersion != 1 || payload.BillingScope != "token" {
		result.ErrorClass = "schema_invalid"
		return result
	}
	observedAt, err := time.Parse(time.RFC3339Nano, payload.ObservedAt)
	if err != nil || observedAt.IsZero() {
		result.ErrorClass = "schema_invalid"
		return result
	}
	if value < 0.001 || value > 10 || math.IsNaN(value) || math.IsInf(value, 0) {
		result.ErrorClass = "value_out_of_band"
		return result
	}
	result.Status = "ok"
	result.SchemaVersion = payload.SchemaVersion
	result.BillingScope = payload.BillingScope
	result.EffectiveRateMultiplier = &value
	result.ObservedAt = observedAt.UTC().Format(time.RFC3339Nano)
	return result
}

func buildNewAPIProbeURL(baseURL, endpoint string) (*url.URL, string) {
	if endpoint != newAPIUsageTokenPath && endpoint != newAPIPricingPath && endpoint != newAPIMessagesPath {
		return nil, "invalid_target"
	}
	parsed, err := url.Parse(strings.TrimSpace(baseURL))
	if err != nil || parsed.Scheme != "https" || parsed.Hostname() == "" || parsed.User != nil {
		return nil, "invalid_target"
	}
	parsed.RawQuery = ""
	parsed.Fragment = ""
	basePath := strings.TrimRight(parsed.EscapedPath(), "/")
	if strings.HasSuffix(basePath, "/v1") {
		basePath = strings.TrimSuffix(basePath, "/v1")
	}
	path := basePath + endpoint
	decodedPath, err := url.PathUnescape(path)
	if err != nil {
		return nil, "invalid_target"
	}
	parsed.Path = decodedPath
	parsed.RawPath = ""
	return parsed, ""
}

type newAPIJSONFetchResult struct {
	body       []byte
	errorClass string
}

func fetchNewAPIJSON(ctx context.Context, client *http.Client, target *url.URL, key string) newAPIJSONFetchResult {
	result := newAPIJSONFetchResult{}
	if target == nil {
		result.errorClass = "invalid_target"
		return result
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target.String(), nil)
	if err != nil {
		result.errorClass = "invalid_target"
		return result
	}
	req.Header.Set("Accept", "application/json")
	if strings.TrimSpace(key) != "" {
		req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(key))
	}
	resp, err := client.Do(req)
	if err != nil {
		result.errorClass = classifySub2BillingProbeError(err)
		return result
	}
	defer resp.Body.Close()
	switch {
	case resp.StatusCode == http.StatusNotFound || resp.StatusCode == http.StatusMethodNotAllowed:
		result.errorClass = "endpoint_unsupported"
		return result
	case resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden:
		result.errorClass = "unauthorized"
		return result
	case resp.StatusCode == http.StatusTooManyRequests:
		result.errorClass = "probe_rate_limited"
		return result
	case resp.StatusCode >= 400 && resp.StatusCode < 500:
		result.errorClass = "http_4xx"
		return result
	case resp.StatusCode < 200 || resp.StatusCode >= 300:
		result.errorClass = "http_5xx"
		return result
	}
	mediaType, _, err := mime.ParseMediaType(resp.Header.Get("Content-Type"))
	if err != nil || mediaType != "application/json" {
		result.errorClass = "bad_content_type"
		return result
	}
	if resp.ContentLength > sub2BillingProbeMaxBodyBytes {
		result.errorClass = "response_too_large"
		return result
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, sub2BillingProbeMaxBodyBytes+1))
	if err != nil {
		result.errorClass = "response_read_error"
		return result
	}
	if len(body) > sub2BillingProbeMaxBodyBytes {
		result.errorClass = "response_too_large"
		return result
	}
	result.body = body
	return result
}

func mapFromProbeValue(value any) map[string]any {
	result, ok := value.(map[string]any)
	if !ok {
		return nil
	}
	return result
}

func probeObjectCandidates(root map[string]any) []map[string]any {
	if root == nil {
		return nil
	}
	result := []map[string]any{root}
	if nested := mapFromProbeValue(root["data"]); nested != nil {
		result = append(result, nested)
	}
	return result
}

func probeString(root map[string]any, keys ...string) string {
	for _, object := range probeObjectCandidates(root) {
		for _, key := range keys {
			if value, ok := object[key].(string); ok && strings.TrimSpace(value) != "" {
				return strings.TrimSpace(value)
			}
		}
	}
	return ""
}

func probeNumber(value any) (float64, bool) {
	switch parsed := value.(type) {
	case float64:
		return parsed, !math.IsNaN(parsed) && !math.IsInf(parsed, 0)
	case float32:
		result := float64(parsed)
		return result, !math.IsNaN(result) && !math.IsInf(result, 0)
	case int:
		return float64(parsed), true
	case int64:
		return float64(parsed), true
	case string:
		result, err := strconv.ParseFloat(strings.TrimSpace(parsed), 64)
		return result, err == nil && !math.IsNaN(result) && !math.IsInf(result, 0)
	default:
		return 0, false
	}
}

func probeDirectRatio(root map[string]any) (float64, bool) {
	for _, object := range probeObjectCandidates(root) {
		for _, key := range []string{"effective_rate_multiplier", "effectiveRateMultiplier", "group_ratio", "groupRatio", "ratio"} {
			if value, ok := probeNumber(object[key]); ok {
				return value, true
			}
		}
	}
	return 0, false
}

func probeGroupRatios(root map[string]any) map[string]float64 {
	for _, object := range probeObjectCandidates(root) {
		for _, key := range []string{"group_ratio", "groupRatio"} {
			raw, ok := object[key].(map[string]any)
			if !ok {
				continue
			}
			result := make(map[string]float64)
			for group, value := range raw {
				parsed, valid := probeNumber(value)
				if strings.TrimSpace(group) != "" && valid && parsed >= 0.001 && parsed <= 10 {
					result[strings.TrimSpace(group)] = parsed
				}
			}
			if len(result) > 0 {
				return result
			}
		}
	}
	return nil
}

func normalizeProbeGroupText(value string) string {
	return strings.Map(func(char rune) rune {
		if unicode.IsLetter(char) || unicode.IsDigit(char) {
			return unicode.ToLower(char)
		}
		return -1
	}, strings.TrimSpace(value))
}

func resolveNewAPIGroupRatio(group, tokenName string, ratios map[string]float64) (string, float64, bool) {
	normalizedGroup := normalizeProbeGroupText(group)
	if normalizedGroup != "" {
		for candidate, ratio := range ratios {
			if candidate == strings.TrimSpace(group) {
				return candidate, ratio, true
			}
		}
		normalizedMatches := make([]string, 0, 2)
		for candidate := range ratios {
			if normalizeProbeGroupText(candidate) == normalizedGroup {
				normalizedMatches = append(normalizedMatches, candidate)
			}
		}
		if len(normalizedMatches) == 1 {
			return normalizedMatches[0], ratios[normalizedMatches[0]], true
		}
		return "", 0, false
	}
	if strings.TrimSpace(tokenName) == "" {
		return "", 0, false
	}
	normalizedName := normalizeProbeGroupText(tokenName)
	bestLength := 0
	best := make([]string, 0, 2)
	for candidate := range ratios {
		normalizedCandidate := normalizeProbeGroupText(candidate)
		if len([]rune(normalizedCandidate)) < 2 || normalizedCandidate == "default" || normalizedCandidate == "auto" {
			continue
		}
		candidateLength := len([]rune(normalizedCandidate))
		if !strings.Contains(normalizedName, normalizedCandidate) {
			continue
		}
		if candidateLength > bestLength {
			bestLength = candidateLength
			best = []string{candidate}
		} else if candidateLength == bestLength {
			best = append(best, candidate)
		}
	}
	if len(best) != 1 {
		return "", 0, false
	}
	return best[0], ratios[best[0]], true
}

// resolveUpstreamGroupFromError sends one deliberately invalid model to the
// upstream and reads the group name from its own rejection text. Some New API
// relays omit group from /api/usage/token/, which leaves group_ratio unmatchable.
func resolveUpstreamGroupFromError(ctx context.Context, client *http.Client, channel *model.Channel, key string) string {
	if channel == nil || strings.TrimSpace(key) == "" {
		return ""
	}
	target, errorClass := buildNewAPIProbeURL(channel.GetBaseURL(), newAPIMessagesPath)
	if errorClass != "" || target == nil {
		return ""
	}
	body, err := common.Marshal(map[string]any{
		"model":      newAPIUnknownModelProbe,
		"max_tokens": 1,
		"messages":   []map[string]any{{"role": "user", "content": "probe"}},
	})
	if err != nil {
		return ""
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, target.String(), strings.NewReader(string(body)))
	if err != nil {
		return ""
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("anthropic-version", "2023-06-01")
	req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(key))
	resp, err := client.Do(req)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		return ""
	}
	payload, err := io.ReadAll(io.LimitReader(resp.Body, sub2BillingProbeMaxBodyBytes))
	if err != nil {
		return ""
	}
	return parseUpstreamGroupFromError(payload)
}

func parseUpstreamGroupFromError(payload []byte) string {
	match := newAPIUpstreamGroupPattern.FindSubmatch(payload)
	if len(match) < 2 {
		return ""
	}
	return strings.TrimSpace(string(match[1]))
}

func executeNewAPIPricingProbe(ctx context.Context, channel *model.Channel) sub2BillingProbeResult {
	return executeNewAPIPricingProbeWithClient(ctx, channel, service.NewStrictProtectedFetchHTTPClient(sub2BillingProbeTimeout))
}

func executeNewAPIPricingProbeWithClient(ctx context.Context, channel *model.Channel, client *http.Client) sub2BillingProbeResult {
	result := sub2BillingProbeResult{
		ChannelID: channel.Id,
		Status:    "failed",
		Source:    "newapi.group_ratio",
		FetchedAt: time.Now().UTC().Format(time.RFC3339Nano),
	}
	if !sub2BillingProbeSupportsChannelType(channel.Type) {
		result.Status = "unsupported"
		result.ErrorClass = "channel_type_unsupported"
		return result
	}
	if strings.TrimSpace(channel.GetSetting().Proxy) != "" {
		result.Status = "unsupported"
		result.ErrorClass = "channel_proxy_unsupported"
		return result
	}
	usageURL, errorClass := buildNewAPIProbeURL(channel.GetBaseURL(), newAPIUsageTokenPath)
	if errorClass != "" {
		result.ErrorClass = errorClass
		return result
	}
	pricingURL, errorClass := buildNewAPIProbeURL(channel.GetBaseURL(), newAPIPricingPath)
	if errorClass != "" {
		result.ErrorClass = errorClass
		return result
	}
	key, _, apiErr := channel.GetNextEnabledKey()
	if apiErr != nil || strings.TrimSpace(key) == "" {
		result.ErrorClass = "key_unavailable"
		return result
	}
	usage := fetchNewAPIJSON(ctx, client, usageURL, key)
	if usage.errorClass != "" {
		if usage.errorClass == "endpoint_unsupported" {
			result.Status = "unsupported"
		}
		result.ErrorClass = usage.errorClass
		return result
	}
	var usagePayload map[string]any
	if err := common.Unmarshal(usage.body, &usagePayload); err != nil {
		result.ErrorClass = "schema_invalid"
		return result
	}
	tokenName := probeString(usagePayload, "name", "token_name", "tokenName")
	group := probeString(usagePayload, "group", "group_name", "groupName", "token_group", "tokenGroup", "user_group", "userGroup")
	directRatio, hasDirectRatio := probeDirectRatio(usagePayload)

	pricing := fetchNewAPIJSON(ctx, client, pricingURL, "")
	if pricing.errorClass != "" {
		if pricing.errorClass == "endpoint_unsupported" {
			result.Status = "unsupported"
		}
		result.ErrorClass = pricing.errorClass
		return result
	}
	var pricingPayload map[string]any
	if err := common.Unmarshal(pricing.body, &pricingPayload); err != nil {
		result.ErrorClass = "schema_invalid"
		return result
	}
	ratios := probeGroupRatios(pricingPayload)
	if len(ratios) == 0 && !hasDirectRatio {
		result.ErrorClass = "schema_invalid"
		return result
	}
	matchedGroup, value, matched := resolveNewAPIGroupRatio(group, tokenName, ratios)
	if !matched {
		// shortcut: relies on the upstream naming its group in the rejection text;
		// replace with a first-class group field once the relay exposes one.
		if observed := resolveUpstreamGroupFromError(ctx, client, channel, key); observed != "" {
			matchedGroup, value, matched = resolveNewAPIGroupRatio(observed, "", ratios)
		}
	}
	if !matched && hasDirectRatio {
		matchedGroup, value, matched = group, directRatio, directRatio >= 0.001 && directRatio <= 10
	}
	if !matched || math.IsNaN(value) || math.IsInf(value, 0) || value < 0.001 || value > 10 {
		result.ErrorClass = "group_unresolved"
		return result
	}
	result.Status = "ok"
	result.UpstreamGroup = matchedGroup
	result.EffectiveRateMultiplier = &value
	result.ObservedAt = time.Now().UTC().Format(time.RFC3339Nano)
	return result
}

// ProbeChannelSub2Billing fetches only the fixed Sub2 billing metadata endpoint
// using the selected channel's stored credential. The credential and upstream
// response body never leave this process.
func ProbeChannelSub2Billing(c *gin.Context) {
	channelID, err := strconv.Atoi(c.Param("id"))
	if err != nil || channelID <= 0 {
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "message": "invalid channel id", "code": "INVALID_CHANNEL_ID"})
		return
	}

	now := time.Now()
	sub2BillingProbeDebounce.Lock()
	lastAttempt := sub2BillingProbeDebounce.lastAttempt[channelID]
	if !lastAttempt.IsZero() && now.Sub(lastAttempt) < sub2BillingProbeMinInterval {
		sub2BillingProbeDebounce.Unlock()
		c.JSON(http.StatusTooManyRequests, gin.H{"success": false, "message": "probe rate limited", "code": "PROBE_RATE_LIMITED"})
		return
	}
	sub2BillingProbeDebounce.lastAttempt[channelID] = now
	sub2BillingProbeDebounce.Unlock()

	channel, err := model.GetChannelById(channelID, true)
	if err != nil || channel == nil {
		c.JSON(http.StatusNotFound, gin.H{"success": false, "message": "channel not found", "code": "CHANNEL_NOT_FOUND"})
		return
	}
	startedAt := time.Now()
	result := executeSub2BillingProbe(c.Request.Context(), channel)
	if result.Status == "unsupported" && result.ErrorClass == "endpoint_unsupported" {
		result = executeNewAPIPricingProbe(c.Request.Context(), channel)
	}
	probeURL, _ := buildSub2BillingProbeURL(channel.GetBaseURL())
	host := ""
	if probeURL != nil {
		host = probeURL.Hostname()
	}
	recordManageAudit(c, "channel.sub2_billing_probe", map[string]interface{}{
		"id":          channelID,
		"target_host": host,
		"result":      result.Status,
		"error_class": result.ErrorClass,
		"duration_ms": time.Since(startedAt).Milliseconds(),
	})
	c.JSON(http.StatusOK, gin.H{"success": true, "message": "", "data": result})
}
