package controller

import (
	"context"
	"errors"
	"net/http"
	"strconv"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func walletProbeTestChannel(channelType int) *model.Channel {
	baseURL := "https://upstream.example/v1"
	return &model.Channel{Id: 12, Type: channelType, Key: "sk-wallet-secret", BaseURL: &baseURL}
}

func TestBuildWalletProbeURLUsesFixedBillingPaths(t *testing.T) {
	for input, expected := range map[string]string{
		"https://upstream.example":             "https://upstream.example/v1/dashboard/billing/subscription",
		"https://upstream.example/v1?secret=x": "https://upstream.example/v1/dashboard/billing/subscription",
		"https://upstream.example/prefix/v1":   "https://upstream.example/prefix/v1/dashboard/billing/subscription",
	} {
		actual, errorClass := buildWalletProbeURL(input, "/v1/dashboard/billing/subscription")
		require.Empty(t, errorClass)
		require.Equal(t, expected, actual.String())
	}
}

func TestExecuteWalletProbeIsProtocolIndependentAndSanitized(t *testing.T) {
	for _, channelType := range []int{constant.ChannelTypeOpenAI, constant.ChannelTypeAnthropic} {
		t.Run(strconv.Itoa(channelType), func(t *testing.T) {
			requests := 0
			client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
				requests++
				require.Equal(t, "Bearer sk-wallet-secret", req.Header.Get("Authorization"))
				if req.URL.Path == "/v1/dashboard/billing/subscription" {
					return sub2BillingResponse(http.StatusOK, "application/json", `{"object":"billing_subscription","hard_limit_usd":6.1}`), nil
				}
				require.Equal(t, "/v1/dashboard/billing/usage", req.URL.Path)
				return sub2BillingResponse(http.StatusOK, "application/json", `{"object":"list","total_usage":343.1766,"ignored":"secret-body"}`), nil
			})}

			result := executeWalletProbeWithClient(context.Background(), walletProbeTestChannel(channelType), client)
			require.Equal(t, "ok", result.Status)
			require.NotNil(t, result.Balance)
			assert.InDelta(t, 2.668234, *result.Balance, 0.0000001)
			assert.Nil(t, result.Currency)
			assert.Equal(t, 2, requests)
			encoded, err := common.Marshal(result)
			require.NoError(t, err)
			assert.NotContains(t, string(encoded), "sk-wallet-secret")
			assert.NotContains(t, string(encoded), "secret-body")
		})
	}
}

func TestExecuteWalletProbeRejectsUnsupportedAndNetworkFailures(t *testing.T) {
	unsupported := &http.Client{Transport: sub2BillingProbeRoundTripper(func(*http.Request) (*http.Response, error) {
		return sub2BillingResponse(http.StatusNotFound, "application/json", `{}`), nil
	})}
	result := executeWalletProbeWithClient(context.Background(), walletProbeTestChannel(constant.ChannelTypeAnthropic), unsupported)
	assert.Equal(t, "unsupported", result.Status)
	assert.Equal(t, "endpoint_unsupported", result.ErrorClass)
	assert.Nil(t, result.Balance)

	failing := &http.Client{Transport: sub2BillingProbeRoundTripper(func(*http.Request) (*http.Response, error) {
		return nil, errors.New("dial failed with sk-wallet-secret")
	})}
	result = executeWalletProbeWithClient(context.Background(), walletProbeTestChannel(constant.ChannelTypeOpenAI), failing)
	assert.Equal(t, "failed", result.Status)
	assert.Equal(t, "network_error", result.ErrorClass)
	assert.Nil(t, result.Balance)
}
