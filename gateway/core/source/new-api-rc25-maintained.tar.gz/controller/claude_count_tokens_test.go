package controller

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func TestCountClaudeTokensReturnsLocalInputTokenEstimate(t *testing.T) {
	gin.SetMode(gin.TestMode)
	recorder := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(recorder)
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/messages/count_tokens", strings.NewReader(`{"model":"claude-opus-5","system":"You are helpful.","messages":[{"role":"user","content":"Count this request."}],"tools":[{"name":"lookup","description":"Look up a value","input_schema":{"type":"object"}}]}`))
	c.Request.Header.Set("Content-Type", "application/json")

	CountClaudeTokens(c)

	require.Equal(t, http.StatusOK, recorder.Code)
	require.JSONEq(t, `{"input_tokens":13}`, recorder.Body.String())
}

func TestCountClaudeTokensRejectsMissingModelOrMessages(t *testing.T) {
	gin.SetMode(gin.TestMode)
	for _, body := range []string{`{"model":"claude-opus-5"}`, `{"messages":[{"role":"user","content":"x"}]}`} {
		recorder := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(recorder)
		c.Request = httptest.NewRequest(http.MethodPost, "/v1/messages/count_tokens", strings.NewReader(body))
		c.Request.Header.Set("Content-Type", "application/json")

		CountClaudeTokens(c)

		require.Equal(t, http.StatusBadRequest, recorder.Code)
		require.Contains(t, recorder.Body.String(), `"invalid_request_error"`)
	}
}
