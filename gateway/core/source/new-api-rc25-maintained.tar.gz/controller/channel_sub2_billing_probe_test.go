package controller

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/stretchr/testify/require"
)

type sub2BillingProbeRoundTripper func(*http.Request) (*http.Response, error)

func (fn sub2BillingProbeRoundTripper) RoundTrip(req *http.Request) (*http.Response, error) {
	return fn(req)
}

func sub2BillingTestChannel() *model.Channel {
	baseURL := "https://upstream.example/v1"
	return &model.Channel{
		Id:      9,
		Type:    constant.ChannelTypeOpenAI,
		Key:     "sk-probe-secret",
		BaseURL: &baseURL,
	}
}

func sub2BillingResponse(status int, contentType, body string) *http.Response {
	return &http.Response{
		StatusCode: status,
		Header:     http.Header{"Content-Type": []string{contentType}},
		Body:       io.NopCloser(strings.NewReader(body)),
	}
}

func TestBuildSub2BillingProbeURLUsesFixedPath(t *testing.T) {
	for input, expected := range map[string]string{
		"https://upstream.example":                 "https://upstream.example/v1/sub2api/billing",
		"https://upstream.example/v1":              "https://upstream.example/v1/sub2api/billing",
		"https://upstream.example/prefix?x=secret": "https://upstream.example/prefix/v1/sub2api/billing",
	} {
		actual, errorClass := buildSub2BillingProbeURL(input)
		require.Empty(t, errorClass)
		require.Equal(t, expected, actual.String())
	}
	for _, input := range []string{"http://upstream.example", "https://user:pass@upstream.example", "not-a-url"} {
		actual, errorClass := buildSub2BillingProbeURL(input)
		require.Nil(t, actual)
		require.Equal(t, "invalid_target", errorClass)
	}
}

func TestExecuteSub2BillingProbeValidatesSchemaAndSanitizesResult(t *testing.T) {
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		require.Equal(t, "https://upstream.example/v1/sub2api/billing", req.URL.String())
		require.Equal(t, "Bearer sk-probe-secret", req.Header.Get("Authorization"))
		return sub2BillingResponse(http.StatusOK, "application/json; charset=utf-8", `{
			"object":"sub2api.key_billing",
			"schema_version":1,
			"billing_scope":"token",
			"effective_rate_multiplier":0.1,
			"observed_at":"2026-07-25T02:03:04Z",
			"ignored_upstream_field":"not returned"
		}`), nil
	})}

	result := executeSub2BillingProbeWithClient(context.Background(), sub2BillingTestChannel(), client)
	require.Equal(t, "ok", result.Status)
	require.NotNil(t, result.EffectiveRateMultiplier)
	require.Equal(t, 0.1, *result.EffectiveRateMultiplier)
	encoded, err := json.Marshal(result)
	require.NoError(t, err)
	require.NotContains(t, string(encoded), "sk-probe-secret")
	require.NotContains(t, string(encoded), "ignored_upstream_field")
}

func TestExecuteSub2BillingProbeRejectsInvalidAndOversizedResponses(t *testing.T) {
	tests := map[string]struct {
		response *http.Response
		want     string
	}{
		"bad schema": {
			response: sub2BillingResponse(http.StatusOK, "application/json", `{"object":"wrong","schema_version":1,"billing_scope":"token","effective_rate_multiplier":0.1,"observed_at":"2026-07-25T02:03:04Z"}`),
			want:     "schema_invalid",
		},
		"bad observed at": {
			response: sub2BillingResponse(http.StatusOK, "application/json", `{"object":"sub2api.key_billing","schema_version":1,"billing_scope":"token","effective_rate_multiplier":0.1,"observed_at":"not-a-time"}`),
			want:     "schema_invalid",
		},
		"out of band": {
			response: sub2BillingResponse(http.StatusOK, "application/json", `{"object":"sub2api.key_billing","schema_version":1,"billing_scope":"token","effective_rate_multiplier":100,"observed_at":"2026-07-25T02:03:04Z"}`),
			want:     "value_out_of_band",
		},
		"oversized": {
			response: sub2BillingResponse(http.StatusOK, "application/json", strings.Repeat("x", sub2BillingProbeMaxBodyBytes+1)),
			want:     "response_too_large",
		},
	}
	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(*http.Request) (*http.Response, error) {
				return test.response, nil
			})}
			result := executeSub2BillingProbeWithClient(context.Background(), sub2BillingTestChannel(), client)
			require.Equal(t, "failed", result.Status)
			require.Equal(t, test.want, result.ErrorClass)
			require.Nil(t, result.EffectiveRateMultiplier)
		})
	}
}

func TestExecuteSub2BillingProbeDoesNotFollowRedirects(t *testing.T) {
	requests := 0
	client := &http.Client{
		Transport: sub2BillingProbeRoundTripper(func(*http.Request) (*http.Response, error) {
			requests++
			response := sub2BillingResponse(http.StatusFound, "text/plain", "redirect")
			response.Header.Set("Location", "https://other.example/private")
			return response, nil
		}),
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
	result := executeSub2BillingProbeWithClient(context.Background(), sub2BillingTestChannel(), client)
	require.Equal(t, "redirect_blocked", result.ErrorClass)
	require.Equal(t, 1, requests)
}

func TestExecuteSub2BillingProbeNeverReturnsCredentialFromNetworkErrors(t *testing.T) {
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(*http.Request) (*http.Response, error) {
		return nil, errors.New("dial failed while using sk-probe-secret")
	})}
	result := executeSub2BillingProbeWithClient(context.Background(), sub2BillingTestChannel(), client)
	encoded, err := json.Marshal(result)
	require.NoError(t, err)
	require.Equal(t, "network_error", result.ErrorClass)
	require.NotContains(t, string(encoded), "sk-probe-secret")
}

func TestBuildNewAPIProbeURLUsesDashboardPathsOutsideV1(t *testing.T) {
	for input, expected := range map[string]string{
		"https://upstream.example":              "https://upstream.example/api/usage/token/",
		"https://upstream.example/v1":           "https://upstream.example/api/usage/token/",
		"https://upstream.example/prefix/v1":    "https://upstream.example/prefix/api/usage/token/",
		"https://upstream.example/prefix?x=key": "https://upstream.example/prefix/api/pricing",
	} {
		endpoint := newAPIUsageTokenPath
		if strings.Contains(expected, "/api/pricing") {
			endpoint = newAPIPricingPath
		}
		actual, errorClass := buildNewAPIProbeURL(input, endpoint)
		require.Empty(t, errorClass)
		require.Equal(t, expected, actual.String())
	}
}

func TestExecuteNewAPIPricingProbeMatchesTokenNameToGroupRatio(t *testing.T) {
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		switch req.URL.Path {
		case "/api/usage/token/":
			require.Equal(t, "Bearer sk-probe-secret", req.Header.Get("Authorization"))
			return sub2BillingResponse(http.StatusOK, "application/json", `{"code":true,"data":{"name":"专用gpt-0.06x"}}`), nil
		case "/api/pricing":
			require.Empty(t, req.Header.Get("Authorization"))
			return sub2BillingResponse(http.StatusOK, "application/json", `{"success":true,"group_ratio":{"专用gpt":0.1,"gpt pro":0.15}}`), nil
		default:
			t.Fatalf("unexpected path %s", req.URL.Path)
			return nil, nil
		}
	})}

	result := executeNewAPIPricingProbeWithClient(context.Background(), sub2BillingTestChannel(), client)
	require.Equal(t, "ok", result.Status)
	require.Equal(t, "newapi.group_ratio", result.Source)
	require.Equal(t, "专用gpt", result.UpstreamGroup)
	require.NotNil(t, result.EffectiveRateMultiplier)
	require.Equal(t, 0.1, *result.EffectiveRateMultiplier)
	encoded, err := json.Marshal(result)
	require.NoError(t, err)
	require.NotContains(t, string(encoded), "sk-probe-secret")
}

func TestXAIChannelUsesNewAPIGroupRatioFallback(t *testing.T) {
	channel := sub2BillingTestChannel()
	channel.Type = constant.ChannelTypeXai
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		switch req.URL.Path {
		case "/v1/sub2api/billing":
			return sub2BillingResponse(http.StatusNotFound, "application/json", `{}`), nil
		case "/api/usage/token/":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"data":{"group":"grok"}}`), nil
		case "/api/pricing":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"group_ratio":{"grok":0.05}}`), nil
		default:
			t.Fatalf("unexpected path %s", req.URL.Path)
			return nil, nil
		}
	})}

	direct := executeSub2BillingProbeWithClient(context.Background(), channel, client)
	require.Equal(t, "unsupported", direct.Status)
	require.Equal(t, "endpoint_unsupported", direct.ErrorClass)

	result := executeNewAPIPricingProbeWithClient(context.Background(), channel, client)
	require.Equal(t, "ok", result.Status)
	require.Equal(t, "newapi.group_ratio", result.Source)
	require.Equal(t, "grok", result.UpstreamGroup)
	require.NotNil(t, result.EffectiveRateMultiplier)
	require.Equal(t, 0.05, *result.EffectiveRateMultiplier)
}

func TestExecuteNewAPIPricingProbePrefersExplicitGroupAndRejectsAmbiguousMatch(t *testing.T) {
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		if req.URL.Path == "/api/usage/token/" {
			return sub2BillingResponse(http.StatusOK, "application/json", `{"code":true,"data":{"name":"friendly-name","group":"gpt pro"}}`), nil
		}
		return sub2BillingResponse(http.StatusOK, "application/json", `{"group_ratio":{"gpt pro":0.15,"gpt-pro":0.2}}`), nil
	})}
	result := executeNewAPIPricingProbeWithClient(context.Background(), sub2BillingTestChannel(), client)
	require.Equal(t, "ok", result.Status)
	require.Equal(t, "gpt pro", result.UpstreamGroup)
	require.Equal(t, 0.15, *result.EffectiveRateMultiplier)

	ambiguous := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		if req.URL.Path == "/api/usage/token/" {
			return sub2BillingResponse(http.StatusOK, "application/json", `{"code":true,"data":{"name":"gptpro"}}`), nil
		}
		return sub2BillingResponse(http.StatusOK, "application/json", `{"group_ratio":{"gpt pro":0.15,"gpt-pro":0.2}}`), nil
	})}
	result = executeNewAPIPricingProbeWithClient(context.Background(), sub2BillingTestChannel(), ambiguous)
	require.Equal(t, "failed", result.Status)
	require.Equal(t, "group_unresolved", result.ErrorClass)
}

func TestParseUpstreamGroupFromErrorExtractsRelayGroup(t *testing.T) {
	payload := []byte(`{"error":{"code":"model_not_found","message":"No available channel for model x under group claude_kiro (distributor) (request id: abc)","type":"new_api_error"}}`)
	require.Equal(t, "claude_kiro", parseUpstreamGroupFromError(payload))

	require.Empty(t, parseUpstreamGroupFromError([]byte(`{"error":{"message":"Model is not available for this group"}}`)))
	require.Empty(t, parseUpstreamGroupFromError([]byte(`not json`)))
}

func TestExecuteNewAPIPricingProbeFallsBackToUpstreamGroupError(t *testing.T) {
	channel := sub2BillingTestChannel()
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		switch req.URL.Path {
		case "/api/usage/token/":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"code":true,"data":{"name":"cc","object":"token_usage"}}`), nil
		case "/api/pricing":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"success":true,"group_ratio":{"claude_kiro":0.1,"claude_youzhi":0.35}}`), nil
		case "/v1/messages":
			return sub2BillingResponse(http.StatusServiceUnavailable, "application/json", `{"error":{"code":"model_not_found","message":"No available channel for model newapi-group-probe-nonexistent under group claude_kiro (distributor)"}}`), nil
		default:
			return sub2BillingResponse(http.StatusNotFound, "application/json", `{}`), nil
		}
	})}

	result := executeNewAPIPricingProbeWithClient(context.Background(), channel, client)
	require.Equal(t, "ok", result.Status)
	require.Equal(t, "claude_kiro", result.UpstreamGroup)
	require.NotNil(t, result.EffectiveRateMultiplier)
	require.Equal(t, 0.1, *result.EffectiveRateMultiplier)
}

func TestExecuteNewAPIPricingProbeKeepsGroupUnresolvedWhenProbeTextHasNoGroup(t *testing.T) {
	channel := sub2BillingTestChannel()
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		switch req.URL.Path {
		case "/api/usage/token/":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"code":true,"data":{"name":"cc","object":"token_usage"}}`), nil
		case "/api/pricing":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"success":true,"group_ratio":{"gpt pro":0.15,"gpt-pro":0.2}}`), nil
		default:
			return sub2BillingResponse(http.StatusNotFound, "application/json", `{"error":{"message":"Model is not available for this group"}}`), nil
		}
	})}

	result := executeNewAPIPricingProbeWithClient(context.Background(), channel, client)
	require.Equal(t, "failed", result.Status)
	require.Equal(t, "group_unresolved", result.ErrorClass)
	require.Nil(t, result.EffectiveRateMultiplier)
}

func TestSub2BillingProbeSupportsRelayChannelTypes(t *testing.T) {
	for _, channelType := range []int{
		constant.ChannelTypeOpenAI,
		constant.ChannelTypeAnthropic,
		constant.ChannelTypeXai,
		constant.ChannelTypeGemini,
		constant.ChannelTypeMoonshot,
		constant.ChannelTypeZhipu,
		constant.ChannelTypeZhipu_v4,
		constant.ChannelTypeDeepSeek,
	} {
		require.True(t, sub2BillingProbeSupportsChannelType(channelType), "type %d must be probed", channelType)
	}
	require.False(t, sub2BillingProbeSupportsChannelType(9999))
}

func TestExecuteNewAPIPricingProbeAcceptsDeepSeekRelay(t *testing.T) {
	channel := sub2BillingTestChannel()
	channel.Type = constant.ChannelTypeDeepSeek
	client := &http.Client{Transport: sub2BillingProbeRoundTripper(func(req *http.Request) (*http.Response, error) {
		switch req.URL.Path {
		case "/api/usage/token/":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"code":true,"data":{"name":"ds41f","object":"token_usage"}}`), nil
		case "/api/pricing":
			return sub2BillingResponse(http.StatusOK, "application/json", `{"success":true,"group_ratio":{"guomo":0.16}}`), nil
		default:
			return sub2BillingResponse(http.StatusServiceUnavailable, "application/json", `{"error":{"message":"No available channel for model x under group guomo (distributor)"}}`), nil
		}
	})}

	result := executeNewAPIPricingProbeWithClient(context.Background(), channel, client)
	require.Equal(t, "ok", result.Status)
	require.Equal(t, "guomo", result.UpstreamGroup)
	require.Equal(t, 0.16, *result.EffectiveRateMultiplier)
}